public interface Displayable {
    void displayTransaction();
}
